// SiYuan version health check — canary probes for the claims in
// references/verified-behaviors.md. Run after every SiYuan upgrade, or
// whenever observed behavior disagrees with the notes.
//
// Probe names are the entry slugs from verified-behaviors.md — keep them
// in sync when renaming entries there.
//
// All probes run inside a throwaway notebook (plus one throwaway asset
// file) and clean up after themselves. Usage:
//   node health_check.mjs [--keep]
//     --keep  leave the test notebook/asset in place for inspection
//
// Output: one PASS/DRIFT/ERROR line per probe + JSON summary.
// DRIFT means the call worked but behavior no longer matches the note —
// go to SKILL.md "Drift protocol".

import fs from "node:fs";
import path from "node:path";
import {
  callSiyuanApi,
  sqlQuery,
  absoluteSyPath,
  waitFor,
  DEFAULTS,
} from "./siyuan_client.mjs";

const keep = process.argv.includes("--keep");
const results = [];
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function record(name, status, detail = "") {
  results.push({ name, status, detail });
  const icon = status === "PASS" ? "✅" : status === "DRIFT" ? "🟡" : "❌";
  console.log(`${icon} ${status.padEnd(5)} ${name}${detail ? ` — ${detail}` : ""}`);
}

async function probe(name, fn) {
  try {
    const drift = await fn();
    if (drift) record(name, "DRIFT", drift);
    else record(name, "PASS");
  } catch (err) {
    record(name, "ERROR", err.message);
  }
}

function walkTypes(node, out = []) {
  if (!node || typeof node !== "object") return out;
  if (node.Type) out.push(node);
  for (const c of node.Children || []) walkTypes(c, out);
  return out;
}

async function readSy(docId) {
  const p = await waitFor(async () => {
    const candidate = await absoluteSyPath(docId);
    return fs.existsSync(candidate) ? candidate : null;
  });
  if (!p) throw new Error("could not resolve .sy path");
  return JSON.parse(fs.readFileSync(p, "utf8"));
}

// ---- setup ------------------------------------------------------------
let nb = null;
let assetName = null;

const version = (await callSiyuanApi("/system/version")).data;
console.log(`SiYuan build: ${version}\n`);

nb = (
  await callSiyuanApi("/notebook/createNotebook", {
    name: "ZZZ-siyuan-ops-体检-可删除",
  })
).data.notebook.id;

// ---- probes -----------------------------------------------------------

await probe("callout-native-parse", async () => {
  const doc = (
    await callSiyuanApi("/filetree/createDocWithMd", {
      notebook: nb,
      path: "/probe-callout",
      markdown: "> [!NOTE] 提示\n> 内容\n\n> 纯引述",
    })
  ).data;
  await sleep(600);
  const nodes = walkTypes(await readSy(doc));
  const callouts = nodes.filter((n) => n.Type === "NodeCallout");
  const quotes = nodes.filter((n) => n.Type === "NodeBlockquote");
  if (callouts.length !== 1 || quotes.length !== 1)
    return `expected 1 callout + 1 blockquote, got ${callouts.length}/${quotes.length}`;
  return null;
});

await probe("custom-doc-id", async () => {
  const wanted = "20200101120000-zzzhchk";
  const got = (
    await callSiyuanApi("/filetree/createDocWithMd", {
      notebook: nb,
      path: "/probe-id",
      markdown: "id probe",
      id: wanted,
    })
  ).data;
  return got === wanted ? null : `returned ${got}`;
});

let refTargetId = null;

await probe("empty-doc-append-fill", async () => {
  const doc = (
    await callSiyuanApi("/filetree/createDocWithMd", {
      notebook: nb,
      path: "/probe-append",
      markdown: "",
    })
  ).data;
  refTargetId = doc;
  await callSiyuanApi("/block/appendBlock", {
    parentID: doc,
    dataType: "markdown",
    data: "# 标题\n\n段落\n\n| a | b |\n| --- | --- |\n| 1 | 2 |\n\n> [!WARNING] 注意\n> 内容",
  });
  await sleep(600);
  const types = walkTypes(await readSy(doc)).map((n) => n.Type);
  for (const t of ["NodeHeading", "NodeParagraph", "NodeTable", "NodeCallout"])
    if (!types.includes(t)) return `missing ${t}`;
  return null;
});

await probe("doc-attrs-set-remove", async () => {
  if (!refTargetId) return "skipped: no target doc";
  await callSiyuanApi("/attr/setBlockAttrs", {
    id: refTargetId,
    attrs: { "custom-probe": "v1", tags: "体检/子级", alias: "probe-alias" },
  });
  let attrs = (await callSiyuanApi("/attr/getBlockAttrs", { id: refTargetId })).data;
  if (attrs["custom-probe"] !== "v1" || !attrs.tags || !attrs.alias)
    return `set failed: ${JSON.stringify(attrs)}`;
  await callSiyuanApi("/attr/setBlockAttrs", {
    id: refTargetId,
    attrs: { "custom-probe": "" },
  });
  attrs = (await callSiyuanApi("/attr/getBlockAttrs", { id: refTargetId })).data;
  if ("custom-probe" in attrs) return "empty-string removal did not clear attr";
  return null;
});

await probe("ref-embed-passthrough", async () => {
  if (!refTargetId) return "skipped: no target doc";
  const doc = (
    await callSiyuanApi("/filetree/createDocWithMd", {
      notebook: nb,
      path: "/probe-ref",
      markdown: `引用: ((${refTargetId} "锚文本"))\n\n{{select * from blocks where id='${refTargetId}'}}`,
    })
  ).data;
  await sleep(600);
  const kd = (await callSiyuanApi("/block/getBlockKramdown", { id: doc })).data
    .kramdown;
  if (!kd.includes(`((${refTargetId}`)) return "block ref missing";
  if (!kd.includes("{{select")) return "embed missing";
  return null;
});

await probe("assets-sql-table", async () => {
  const blocks = await sqlQuery("SELECT count(*) AS c FROM blocks");
  const assets = await sqlQuery("SELECT count(*) AS c FROM assets");
  if (!Array.isArray(blocks) || !Array.isArray(assets))
    return "unexpected result shape";
  return null;
});

await probe("asset-rename-full-chain", async () => {
  // renameAsset takes {oldPath, newName}; newName is a display name WITHOUT
  // extension — kernel appends -<timestamp>-<rand> and keeps the extension.
  const ts = Date.now();
  assetName = `zz-health-probe-${ts}.png`;
  const png = Buffer.from(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==",
    "base64"
  );
  fs.writeFileSync(path.join(DEFAULTS.dataRoot, "assets", assetName), png);
  const doc = (
    await callSiyuanApi("/filetree/createDocWithMd", {
      notebook: nb,
      path: "/probe-asset",
      markdown: `![](assets/${assetName})`,
    })
  ).data;
  await callSiyuanApi("/sqlite/flushTransaction", {});
  await sleep(1000);
  const res = await callSiyuanApi("/asset/renameAsset", {
    oldPath: `assets/${assetName}`,
    newName: `zz-health-probe-${ts}-renamed`,
  });
  const newPath = res.data?.newPath;
  if (!newPath) return "no newPath in response";
  await sleep(1000);
  if (fs.existsSync(path.join(DEFAULTS.dataRoot, newPath)))
    assetName = path.basename(newPath);
  const kd = (await callSiyuanApi("/block/getBlockKramdown", { id: doc })).data
    .kramdown;
  if (!kd.includes(newPath))
    return `doc kramdown not rewritten (expected ${newPath})`;
  return null;
});

await probe("asset-endpoints-mounted", async () => {
  const res = await callSiyuanApi("/asset/getMissingAssets");
  return Array.isArray(res.data) ? null : "unexpected shape";
});

await probe("table-dom-update-para-to-table", async () => {
  // Build a table DOM from the kernel's own rendering, inject colspan +
  // fn__none, then updateBlock(dataType=dom) onto a plain paragraph.
  const srcDoc = (
    await callSiyuanApi("/filetree/createDocWithMd", {
      notebook: nb,
      path: "/probe-table-src",
      markdown: "| a | b |\n| --- | --- |\n| 1 | 2 |",
    })
  ).data;
  await sleep(600);
  const srcContent = (await callSiyuanApi("/filetree/getDoc", { id: srcDoc }))
    .data.content;
  const blocks = srcContent
    .split(/(?=<div data-node-id=)/)
    .filter((s) => s.trim());
  let tableDom = blocks.find((b) => b.includes('data-type="NodeTable"'));
  if (!tableDom) return "getDoc returned no NodeTable block DOM";
  tableDom = tableDom.replace(
    /data-node-id="[^"]*"/,
    'data-node-id="20200101120001-tblprob"'
  );
  let th = 0;
  // (?=[\s>]) keeps <thead> from matching
  tableDom = tableDom.replace(/<th(?=[\s>])/g, (m) => {
    th += 1;
    if (th === 1) return '<th colspan="2"';
    if (th === 2) return '<th class="fn__none"';
    return m;
  });
  if (th < 2) return "could not find two <th> cells to modify";
  const dstDoc = (
    await callSiyuanApi("/filetree/createDocWithMd", {
      notebook: nb,
      path: "/probe-table-dst",
      markdown: "占位段落",
    })
  ).data;
  await sleep(600);
  const kids = (await callSiyuanApi("/block/getChildBlocks", { id: dstDoc }))
    .data;
  const paraId = kids?.[0]?.id;
  if (!paraId) return "no paragraph block to update";
  await callSiyuanApi("/block/updateBlock", {
    id: paraId,
    dataType: "dom",
    data: tableDom,
  });
  await sleep(800);
  const sy = JSON.stringify(await readSy(dstDoc));
  if (!sy.includes("NodeTable")) return ".sy has no NodeTable";
  if (!sy.includes("colspan")) return ".sy missing colspan property";
  if (!sy.includes("fn__none")) return ".sy missing fn__none covered cell";
  return null;
});

// TODO: sql readonly-mode rejection probe — the readonly/multiple mode
// request shape has not been pinned down locally yet; add once confirmed.

// ---- cleanup ----------------------------------------------------------
if (!keep) {
  if (nb) await callSiyuanApi("/notebook/removeNotebook", { notebook: nb });
  if (assetName) {
    const p = path.join(DEFAULTS.dataRoot, "assets", assetName);
    if (fs.existsSync(p)) fs.unlinkSync(p);
  }
  console.log("\n(临时笔记本与探针资产已清理)");
} else {
  console.log(`\n(--keep: 保留测试笔记本 ${nb} 与资产 ${assetName})`);
}

const summary = {
  version,
  date: new Date().toISOString().slice(0, 10),
  pass: results.filter((r) => r.status === "PASS").length,
  drift: results.filter((r) => r.status === "DRIFT").length,
  error: results.filter((r) => r.status === "ERROR").length,
  results,
};
console.log(`\n${JSON.stringify(summary, null, 2)}`);
process.exit(summary.drift + summary.error > 0 ? 1 : 0);
