// Create a SiYuan document from a markdown file, then resolve its .sy path.
// Usage: node create_doc.mjs <markdown-file> <hpath> [notebook-id] [--id=<custom-id>]
//   notebook-id defaults to the Official notebook (see siyuan_client DEFAULTS).
//   --id lets you control the document ID (and therefore its native created
//   time, which SiYuan derives from the ID prefix). Verified 2026-07-04.

import fs from "node:fs";
import {
  callSiyuanApi,
  absoluteSyPath,
  waitFor,
  DEFAULTS,
} from "./siyuan_client.mjs";

const args = process.argv.slice(2);
const idFlag = args.find((a) => a.startsWith("--id="));
const positional = args.filter((a) => !a.startsWith("--"));
const [markdownPath, hpath, notebookArg] = positional;
const notebook = notebookArg || DEFAULTS.officialNotebookId;

if (!markdownPath || !hpath) {
  console.error(
    "Usage: node create_doc.mjs <markdown-file> <hpath> [notebook-id] [--id=<custom-id>]"
  );
  process.exit(1);
}

const markdown = fs.readFileSync(markdownPath, "utf8");
const payload = { notebook, path: hpath, markdown };
if (idFlag) payload.id = idFlag.slice(5);

const created = await callSiyuanApi("/filetree/createDocWithMd", payload);
const docId = created.data;

const syPath = await waitFor(async () => {
  const p = await absoluteSyPath(docId);
  return fs.existsSync(p) ? p : null;
});

console.log(
  JSON.stringify({ markdownPath, notebook, hpath, docId, syPath }, null, 2)
);
