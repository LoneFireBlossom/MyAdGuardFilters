// Find SiYuan documents by exact title via the SQL API.
// Usage: node locate_doc.mjs <title> [--like]
//   --like  substring match instead of exact title

import path from "node:path";
import { sqlQuery, DEFAULTS } from "./siyuan_client.mjs";

const args = process.argv.slice(2);
const like = args.includes("--like");
const title = args.filter((a) => !a.startsWith("--"))[0];

if (!title) {
  console.error("Usage: node locate_doc.mjs <title> [--like]");
  process.exit(1);
}

const escaped = title.replace(/'/g, "''");
const where = like ? `content LIKE '%${escaped}%'` : `content = '${escaped}'`;
const rows = await sqlQuery(
  `SELECT id, content, box, path, hpath, updated FROM blocks WHERE type = 'd' AND ${where} ORDER BY updated DESC LIMIT 50`
);

const matches = rows.map((row) => ({
  id: row.id,
  title: row.content,
  updated: row.updated,
  hpath: row.hpath,
  notebook: row.box,
  syPath: path.join(DEFAULTS.dataRoot, row.box, row.path),
}));

console.log(JSON.stringify({ title, like, count: matches.length, matches }, null, 2));
