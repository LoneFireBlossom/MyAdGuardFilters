// Generic SiYuan API client for this machine.
// - Token: env SIYUAN_API_TOKEN (optional on localhost, recommended).
// - Retry: network errors and 5xx get retried with backoff; SiYuan-level
//   errors (code !== 0) do NOT retry — they are semantic failures.
// - Node fetch ignores proxy env vars, so local proxy tooling (Surge)
//   cannot intercept these calls the way it can with curl.

import path from "node:path";

export const DEFAULTS = {
  apiBase: process.env.SIYUAN_API_BASE || "http://127.0.0.1:6806/api",
  dataRoot:
    process.env.SIYUAN_DATA_ROOT ||
    "/Users/lonefireblossom/Documents/Mooncell/Mooncell-SiYuan/data",
  officialNotebookId: "20260703190408-xa3dc4z",
};

export class SiyuanApiError extends Error {
  constructor(endpoint, response) {
    super(`SiYuan API ${endpoint} -> code ${response?.code}: ${response?.msg}`);
    this.endpoint = endpoint;
    this.response = response;
  }
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export async function callSiyuanApi(endpoint, payload = {}, opts = {}) {
  const apiBase = opts.apiBase || DEFAULTS.apiBase;
  const token = opts.token ?? process.env.SIYUAN_API_TOKEN;
  const retries = opts.retries ?? 3;
  const headers = { "Content-Type": "application/json" };
  if (token) headers.Authorization = `Token ${token}`;

  let lastError;
  for (let attempt = 0; attempt <= retries; attempt += 1) {
    try {
      const res = await fetch(`${apiBase}${endpoint}`, {
        method: "POST",
        headers,
        body: JSON.stringify(payload),
      });
      if (res.status >= 500) {
        lastError = new Error(`HTTP ${res.status} on ${endpoint}`);
      } else {
        const json = await res.json();
        if (json.code !== 0 && !opts.allowNonZero) {
          throw new SiyuanApiError(endpoint, json);
        }
        return json;
      }
    } catch (err) {
      if (err instanceof SiyuanApiError) throw err;
      lastError = err;
    }
    if (attempt < retries) await sleep(300 * 2 ** attempt);
  }
  throw lastError;
}

// Convenience wrappers -------------------------------------------------

export async function sqlQuery(stmt, opts = {}) {
  const json = await callSiyuanApi("/query/sql", { stmt }, opts);
  return json.data || [];
}

export async function absoluteSyPath(docId, opts = {}) {
  const json = await callSiyuanApi("/filetree/getPathByID", { id: docId }, opts);
  const dataRoot = opts.dataRoot || DEFAULTS.dataRoot;
  return path.join(dataRoot, json.data.notebook, json.data.path);
}

export async function waitFor(fn, { attempts = 12, delayMs = 500 } = {}) {
  let last;
  for (let i = 0; i < attempts; i += 1) {
    last = await fn();
    if (last) return last;
    await sleep(delayMs);
  }
  return last;
}
