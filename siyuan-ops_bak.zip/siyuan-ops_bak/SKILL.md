---
name: siyuan-ops
description: Operate the local SiYuan (思源笔记) workspace on this machine — read/write documents and blocks over the kernel HTTP API or CLI, set attributes, build and fill databases (attribute views), manage assets, run SQL queries, verify writes, and diagnose "write succeeded but looks wrong" issues. Use for ANY task that touches SiYuan data: creating/editing docs, block repair, doc attributes, database rows and views, asset rename/compress/cleanup, snapshots, post-upgrade health checks. Not for exam-note content rules or Obsidian note migration specifics (use obsidian-to-siyuan-exam-notes for those).
---

# SiYuan Ops

Long-term knowledge base and toolkit for operating this machine's SiYuan workspace from agent sessions. Content rules for specific note types live in other skills; this skill owns the "how to operate SiYuan safely" layer.

## Start here

1. Environment facts (paths, notebook IDs, token, surfaces): [references/environment.md](references/environment.md) — the only authoritative copy.
2. Before ANY write, know your tier: [references/api-classification.md](references/api-classification.md) (R / W1 / W2 / W3 by write depth, with per-tier discipline).
3. Uncertain whether a documented behavior still holds? Run `node scripts/health_check.mjs` — canary probes for the key claims, in a throwaway notebook.

## Routing: task → what to read

| 任务类型 | 读什么 |
|---|---|
| 只读查询（SQL、找文档、读块） | environment.md 即可；SQL 语义盲区再看 core-source-notes 的 sql 条目 |
| 建文档 / 追加内容 / 设属性 (W1) | api-classification.md 的 W1 节 + format-and-blocks.md |
| 改结构 / 移动 / 删除 / 改引用 (W2) | api-operation-rules.md + core-source-notes.md 对应家族条目 |
| 数据库（AV）任何读写 | av-source-notes.md + api-operation-rules.md 的 AV 节 |
| 资产维护（改名/压缩/清理） | recipes.md + verified-behaviors.md 资产节 |
| 导入 / 回滚 / 笔记本与工作区生命周期 (W3) | api-operation-rules.md + core-source-notes.md 对应条目；用户确认 + 快照强制 |
| "写成功了但看起来不对" | runtime-quirks.md（先查 UI 刷新与索引滞后，再怀疑写入） |
| 思源升级后 / 行为与笔记不符 | 下方 Drift protocol |
| 想先知道“哪些已经读透，哪些还没补” | source-coverage-map.md |

## Hard rules

1. 写入走运行中的内核（HTTP API 或 Kernel CLI）；`.sy` 文件严禁作为常规写入面，默认只作验证面。只有在**反复尝试正常写法后仍确认不可行、且当前目标只能靠直接改 `.sy` 才可能完成**时，才允许把直接写 `.sy` 作为候选方案；并且**在动手前必须先向用户说明原因并获得明确批准**。
2. 按 [api-classification.md](references/api-classification.md) 的分级执行对应验证纪律；返回码 200 不是结构正确的证据。
3. 验证阶梯：返回码 → 目标查找 → kramdown 读回 → `.sy` 结构 → 最后才是搜索/UI（搜索索引有滞后）。
4. W2 首次在新版本上使用：先在临时笔记本探针。W3：用户明确确认 + repo 快照，逐步执行不连锁。
5. 对用户数据的任何批量操作：先给方案、拿到明确执行指令再动手；操作后如实报告用了什么面、改了什么、怎么验证的。

## Drift protocol（版本漂移应对）

思源升级后（尤其 alpha 通道），或操作中发现行为与笔记不符时：

1. 停下当前写操作，跑 `node scripts/health_check.mjs` —— 输出逐条 PASS/DRIFT。
2. 漂移的条目定位到所属家族 → 查该版本 changelog → 只重验/重读该家族（source-notes 里有源码锚点，做增量复核，不整库重读）。
3. 更新对应笔记条目（改写并删除旧文），刷新 environment.md 的"最后验证版本"。
4. 公开 API（API.zh-CN.md 内的）极少破坏性变更；`av/*` 等未文档化端点（⚠ 标记）没有兼容承诺，升级后优先复测。

## Contribution rules（写给未来会话，含其他 agent）

1. **一个事实只有一个家**——按上面路由表决定归属；别处需要就链接过去，不要复制。
2. 每条新结论带**日期 + 证据标签**（doc-backed / live-tested / source-backed+锚点）。
3. **改结论 = 删旧文**，不追加矛盾版本；本知识库已因追加式生长出过重复与孤儿碎片，引以为戒。
4. 关键结论尽量附一行自证探针（见 verified-behaviors.md 的格式）。

## Files

- [references/environment.md](references/environment.md) — 本机参数唯一之家
- [references/api-classification.md](references/api-classification.md) — R/W1/W2/W3 分级 + 新端点入库规则
- [references/api-operation-rules.md](references/api-operation-rules.md) — 操作纪律与各家族安全默认
- [references/core-source-notes.md](references/core-source-notes.md) — 深度源码笔记：块/文档树/文件资产/SQL/导入/历史仓库/工作区/MCP
- [references/av-source-notes.md](references/av-source-notes.md) — 深度源码笔记：数据库（属性视图）全家族
- [references/format-and-blocks.md](references/format-and-blocks.md) — 块形态与 markdown 语法形态
- [references/runtime-quirks.md](references/runtime-quirks.md) — UI 刷新/索引滞后等运行时怪癖
- [references/verified-behaviors.md](references/verified-behaviors.md) — 本机实测清单（每条带自证探针）
- [references/recipes.md](references/recipes.md) — 操作配方（PNG→JPEG 压缩等）
- [references/source-coverage-map.md](references/source-coverage-map.md) — 源码覆盖总览：哪些家族已读透、哪些还值得补 probe
- `scripts/siyuan_client.mjs` — 通用 API 客户端（token + 重试）
- `scripts/locate_doc.mjs` — 按标题定位文档（SQL）
- `scripts/create_doc.mjs` — 建文档（支持自定义 ID）并解析 `.sy` 路径
- `scripts/health_check.mjs` — 版本体检金丝雀探针套件
