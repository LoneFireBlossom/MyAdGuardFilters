# Operational Recipes

可复用的操作配方。每个配方注明状态：**designed**（设计完成未实施）/ **validated**(日期)（真实跑过）。配方是"资产重构"类操作的标准骨架，新配方按同样格式追加。

## Recipe 1: 大 PNG 压缩为 JPEG/WebP 并更新全库引用

状态：**designed**（关键依赖已实测：见 verified-behaviors 的 `asset-rename-full-chain`——`renameAsset` **无法改扩展名**，所以本配方走"新资产 + 逐块重写"路线；整条配方尚未在真实资产上实施）。

问题：`data/assets` 里的大 PNG 要压成有损格式；格式转换必然改文件名，所有引用点失效。引用点有三类：普通块的 `![](assets/x.png)`、文档题头图（`title-img` 属性）、数据库资源列（MAsset 单元格）。

前置事实（live-tested 2026-07-04）：`renameAsset` 只能改基名（自动追加时间戳后缀、保留扩展名），能让内核重写普通块引用——**适用于同扩展名整理命名，不适用于格式转换**。格式转换必须自己重写引用。

流程（单文件；批量=循环+清单+断点状态）：

1. **盘点**：`SELECT DISTINCT block_id, root_id, path, title FROM assets WHERE path LIKE '%.png'` + 文件大小阈值过滤（参数化，如 >500KB）。`title='title-img'` 的行是题头图引用，单独归类。
2. **Alpha 检测**：`sips -g hasAlpha <file>`。有透明通道：跳过，或转 WebP（有损 WebP 保留透明、压缩率优于 JPEG、思源可显示）——不要无脑压平成 JPEG。
3. **转码为新资产**：`sips -s format jpeg -s formatOptions 85 <src> --out data/assets/<原基名>-c.jpeg`（或 `cwebp -q 85`）。旧文件暂不删。
4. **逐块重写引用**（W2）：对盘点出的每个 `block_id`：
   - 普通块：`getBlockKramdown` → 把旧路径（含 URL 编码变体）替换为新路径 → `updateBlock`。注意 `updateBlock` 会换被更新块的子块 ID——含图段落是叶子块（无子块）安全；图片在列表/引述里时，定位到**叶子段落块**再更新，不要更新容器块。
   - 题头图：`setBlockAttrs {"title-img": "background-image:url(assets/新名)"}`（先 `getBlockAttrs` 看原值形态照抄结构）。
   - AV 资源列：`renderAttributeView` 定位目标单元格 → `setAttributeViewBlockAttr` 更新。2026-07-04 已实测同类写法可更新 `MAsset` 与指向 `assets/...` 的 `URL` 单元格；真正批量执行前仍建议先在测试库抽一条完整跑通。
5. **审计**：
   - `SELECT count(*) FROM assets WHERE path='assets/x.png'` → 0（flushTransaction 后查）；
   - `/api/asset/getMissingAssets` → 空；
   - 抽查引用块 kramdown + 打开一篇文档目检渲染。
6. **删旧资产**：审计通过后删除旧 PNG 文件。
7. **批量前置**：repo 快照（`/api/repo/createSnapshot`）；转码后同步会重传这批资产（一次性成本）。

注意：
- 文字截图的 JPEG 振铃伪影：质量 ≥85 通常可接受；图表/线稿宁可 WebP。
- 别用"JPEG 字节塞进 .png 文件名"的偷懒法——渲染不坏，但审计面从此说谎。

## Recipe 2: 资产改名（同扩展名）

状态：**validated 2026-07-04**（health_check 含此探针）。

`POST /api/asset/renameAsset {"oldPath":"assets/旧全名.png","newName":"新基名"}` —— 内核改文件名并重写普通块引用。注意：参数键名错误（如 `newPath`）会返回 code 0 但**什么都不做**；最终名带自动后缀，从响应 `data.newPath` 取；题头图、AV 的 `MAsset` 列，以及指向 `assets/...` 的 AV `URL` 值都已实测会被重写，但 UI 派生显示面仍建议抽查。

## Recipe 3: 通过 API 写原生合并单元格表格

状态：**validated 2026-07-05**（本机 3.7.1）。

问题：需要在思源里得到真正的原生合并单元格表格，而不是“看起来像表格”的 HTML，也不是把 `{: colspan=2}` 之类语法当普通文字显示出来。

前置事实（一行版，正式版见 format-and-blocks.md 表格节）：块写 API 的 `dataType` 支持 `markdown` / `dom`；原生合并单元格**必须**走 `dataType="dom"` + 完整 `NodeTable` 块 DOM，Markdown 管道表 / 原始 HTML `<table>` 不可靠。验证信号与探针：verified-behaviors 的 `table-dom-*` 三条（health_check 已含金丝雀）。

流程：

1. **准备 DOM 源**：从一个已经正确的原生合并表格所在文档调用 `getDoc`，从返回的 `content` 中抽出整块 `<div data-type=\"NodeTable\" ...>...</div>`。复杂表格不要手搓 Markdown；目标既然是原生 merged-cell，就不要先尝试 Markdown/HTML 再补救。
2. **选择写入方式**：
   - 新增到文档里：`appendBlock` 或 `insertBlock`，`dataType=\"dom\"`。
   - 原地替换一个现有块：`updateBlock`，`dataType=\"dom\"`。如果原块是图片段落，这条最适合“图转表”。
3. **提交后立即核验**：
   - `getDoc` 看渲染块是否为 `data-type=\"NodeTable\"`；
   - DOM 中是否仍有 `class=\"fn__none\"`、`rowspan`、`colspan`；
   - 必要时直接读 `.sy`，确认存在 `NodeTableCell.Properties.colspan/rowspan` 与隐藏覆盖格。
4. **再做内容级修整**：若需要改居中、列宽、局部单元格文本，优先在同一套 DOM 上改后再写回；不要先退回 Markdown 再试图“自动恢复”合并结构。

注意：

- `updateBlock` 是结构替换，不是轻量属性改写；会有它自己的块替换语义，涉及子块 ID 风险时先看 `runtime-quirks.md`。
- 如果目标只是普通无合并表格，Markdown 路线更简单；但只要目标明确是思源原生 merged-cell 结构，就应直接走 DOM 路线，不要把 Markdown/HTML 当成主方案。

## Recipe 4: 写响应式 HTML / SVG 图表块

状态：**validated 2026-07-05**（本机 3.7.1，结论为“可做，但必须守住单块写入与统一坐标系”）。

问题：想把一张图表图片增强成思源中的可缩放 HTML/SVG 图形块，并希望它随页面宽度自适应，而不是固定像素撑破容器。

前置事实（一行版，正式版见 format-and-blocks.md 的 HTML / SVG 块节）：多行独段 HTML 才稳定落成 `NodeHTMLBlock`；多行 SVG 走 `updateBlock(dataType=markdown)` 会拆块；"容器自适应"≠"内部边界闭合"。探针：verified-behaviors 的 `html-block-multiline-only` / `svg-update-markdown-splits` / `svg-viewbox-overflow`。

流程：

1. **先把图形结构参数化**：不要手写一堆互相独立的像素值。至少把这些量收成同一套参数：
   - 轴宽
   - 左侧标题带宽 / 行标签带宽
   - 右侧数值预留
   - 刻度步长
   - 图例和标题的纵向位置
2. **由参数反推画布尺寸**：
   - 先算内部元素的真实最右边界（图条最大宽度 + 右侧数值预留 + 图例/标题需要的宽度）
   - 再把 SVG `viewBox` 宽度设成这一边界，而不是手填一个“差不多”的常量
3. **先决定落位方式**：
   - 如果原图本身也有保留价值，默认不要删原图；优先做成“原图 + 重绘 HTML/SVG 块”的双轨结构，让新块紧跟在原图后面。
   - 对这种“插在某块后面”的落位，优先用 `insertBlock { previousID: <imageBlockId>, dataType:\"dom\" }`；`previousID` 表示“紧跟在哪个块后面”，不是“把 parent 当成 previousID 的别名”。
4. **HTML 块写入策略**：
   - 新建图表文档或首次探路：可先用“多行原始 HTML、独占一段”的 markdown 路线建出单个 `NodeHTMLBlock`
   - 一旦要把它稳定插回正式文档，优先准备一个**完整 HTML 块 DOM 模板**：从现有 `NodeHTMLBlock` 的 `getDoc` 结果里抽整块 `<div data-type=\"NodeHTMLBlock\" ...>`，只替换其中的 `data-content`、`data-node-id`、`updated`
   - 已有图表块的后续精修：优先走 `dataType=\"dom\"` 回写完整 HTML 块 DOM，不要默认用 `updateBlock(dataType=markdown)` 直接塞多行 SVG
5. **写后立即核验**：
   - `getDoc` / `.sy` 确认目标仍是**一个** `NodeHTMLBlock`
   - 没有额外冒出一串被转义的 `<g> / <text> / <rect>` 段落
   - 如果目标是“插在原图后面”，用 `/block/getChildBlocks(<父列表项ID>)` 核对图片块的**下一个兄弟块**就是新 HTML 块
   - 再看渲染是否贴合页面宽度
6. **如果仍然“右边长出来”**：
   - 先检查内部最大 `x`、右侧数值标签、图例/标题位置与 `viewBox` 是否一致
   - 不要先去乱改 `max-width`、`padding-right`、`margin`

注意：

- “页面自适应”和“图本体边界闭合”是两回事；前者靠容器，后者靠统一坐标系。
- 对同类图（横向条形图、双柱对照图等），应优先抽成生成脚本，由数据和参数生成 SVG/HTML；不要每张图都靠肉眼微调右边界。
- 如果你验证的是“兄弟块位置”，不要拿 `SELECT ... FROM blocks ORDER BY created` 当树顺序；块树顺序看 `getChildBlocks`，SQL 只适合做辅助盘点。
