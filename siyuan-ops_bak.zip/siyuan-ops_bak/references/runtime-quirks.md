# Runtime Quirks (observed on this machine)

"写入成功但看起来不对"时先读这个，再决定要不要怀疑自己的写入。以下都是本机验证过的现象；具体日期按各条上下文，当前最后复核版本见 environment.md。

## UI 刷新滞后（最常见的假故障）

- API 写入成功后，桌面端 UI 可能**不立即**反映：
  - 新建的子文档在磁盘上存在、能按 ID 解析，但父文档树不显示——折叠再展开父节点才出现。
  - API 创建/更新的数据可能需要树折叠/展开或类似 UI 刷新后，各面板才一致。
- 判定归属：先用 `getPathByID` / `getBlockKramdown` / `.sy` 确认持久层，持久层对了就是 UI 刷新问题，不要回头改数据。
- 复现思源自身问题时，先用官方原生对象做夹具（callout 用 NOTE/TIP/WARNING），排除自定义样式/插件因素。

## 索引与搜索的时间差

- CLI/API 返回成功 ≠ 立即可搜。写后立刻全文搜索查不到是正常现象，不是写入失败。
- 验证顺序：返回码 → 目标查找（ID/路径）→ kramdown 读回 → `.sy` → 最后才是搜索/UI。
- 对某些**内核侧批量/联动改写**，不同读面也可能短暂不一致。2026-07-04 对 `renameAsset` + `title-img` 的 probe 里：
  - `getBlockKramdown`、`.sy`、`assets` SQL 都已经是新路径
  - `getBlockAttrs` 同时仍返回旧的 `title-img`
- 判定归属：遇到这种差异，优先信 kramdown/`.sy`/目标专用索引面，不要只因 `getBlockAttrs` 落后就再做一次写入。
- 2026-07-05 的图表 HTML 块插入 probe 里，`insertBlock(previousID=图片块ID)` 已经把新块放到了**正确的紧邻兄弟位置**，但某些 SQL / 搜索面一开始并不适合拿来判定这个“相邻关系”：
  - `blocks` 表按 `created` 排序，不等于块树里的兄弟顺序
  - 以 `content like '%data-chart-key%'` 之类方式查 HTML 标记，也不该当成第一真相面
- 判定归属：如果你要确认“某个 HTML/SVG 块是不是紧跟在图片后面”，优先信 `/block/getChildBlocks(parentID)` 返回的同父块顺序；SQL 可以做补充盘点，但不要拿它替代块树顺序验证。
- repo 文档回滚也出现过类似现象：2026-07-04 的 `.sy` rollback probe 里，`getBlockKramdown` 已恢复旧版本内容，但 `getBlockAttrs.updated` 仍是较新的时间值。
- 判定归属：repo 单文件回滚后，如果内容面和 attrs 面冲突，先信 `getBlockKramdown` / `.sy` / snapshot open 结果，再决定是否需要额外刷新观察。
- 同日 AV JSON rollback probe 里，`openRepoSnapshotFile` 对 `data/storage/av/*.json` 走的是纯文本 JSON 预览面，不是 `.sy` 那种渲染面；判断版本时可以直接看 JSON 内容。
- AV 也有类似的“ID 面不一致”坑：
  - 文档树里的 `NodeAttributeView` 块 ID 不等于底层 `AttributeViewID`
  - 某些 AV API/探针如果误把块 ID 当成 `avID`，可能拿到误导性结果，甚至触发读路径的自建视图逻辑
- 判定归属：对 AV，一旦结果怪，先回 `.sy` 或 `data/storage/av/*.json` 确认真正的 `AttributeViewID`。

## 日志判读

- 重启窗口期的 `serve.go:259 ... use of closed network connection` 属正常关停/启动噪声，不是刷新 bug 的证据。
- 历史实验里见过 `tree.go:158 ... invalid path`，可解释早期不稳定，但与当前刷新症状无必然关系。

## 路径安全门槛

- `globalCopyFiles` 这类接受工作空间外绝对路径的接口，会先过 `IsSensitivePath`。
- 工作空间外若落在系统敏感前缀（如 `/var`、`/tmp`、`/etc`、家目录常见凭据目录）会被直接拒绝；这不是偶发 bug，是有意的外泄防护。
- 2026-07-04 本机 probe 里，从 macOS 临时目录 `/var/folders/...` 复制测试文件到 `data/assets` 被拒绝；改用普通非敏感目录后成功。
- 判定归属：遇到 `refuse to copy sensitive file [...]`，先换非敏感源路径，不要怀疑目标目录或 assets 逻辑本身。

## 修复脚本的经典教训

- 重建 `NodeParagraph` 时如果先降成纯文本再拼 markdown，**图片会被吞掉**（`![](assets/...)` 与带宽度 IAL 的图片尤甚）。正确做法：段落也优先走 `getBlockKramdown` 按逻辑块拆分；含图片的修复完成后必须再做一次图片核验。
- `updateBlock` 是删旧插新：被更新块内部的**子块 ID 全部变化**，外部指向这些子块的引用会断。只改属性用 `setBlockAttrs`，别动 `updateBlock`。
- **对 `NodeCallout` 一律按“精修”处理，不做整块 markdown 重写。** 这不是“复杂 callout 才这样”的条件规则，而是默认纪律：改标题就改标题，改段落就改段落，改表格就改表格，改列表项就改列表项；不要把整个 callout 容器当成一段 markdown 回写。原因很直接：
  - 整块重写 callout 容器时，内部原生子块（行内公式、数学块、表格、图片、嵌套列表）很容易一起被重新解析，导致不相关内容退化。
  - 本机已真实踩过两类坑：一类是 callout 内的原生合并单元格表格被整块重写后损坏；另一类是行内公式边界在整块重写后丢失，退化成普通文本或反斜杠节点。
  - 这条统一规则会让步骤稍微细一点，但不会显著增加复杂度；换来的好处是明显更稳，也避免临场判断“这个 callout 算不算简单”。
- **图表类 HTML/SVG 也不要把 `updateBlock(dataType=markdown)` 当万能整块替换器**（结构事实见 format-and-blocks.md 的 HTML / SVG 块节）。
  - 判定归属：写完后同一目标附近多出一串被转义的 `<g> / <text> / <rect>` 段落 → 先怀疑 markdown 写面对多行 SVG 的重解析（应改走 `dataType=dom` 回写完整块 DOM），不要误判成“只是宽度不对”继续在坏结构上调样式。
- **图表增强默认应走“保留原图 + 追加 HTML/SVG 兄弟块”，不要先删原图再赌新块一步到位。**
  - 原因：原图既是视觉对照，也是失败时的兜底；图表重绘的风险主要在新块写面和坐标系，不在原图本身。先把新块插到图片后面，确认结构和渲染都对，再决定是否还要做别的整理。
- **自适应看着不对，不一定是 CSS 容器宽度的问题**（“容器层 vs 内容层”两层模型见 format-and-blocks.md）。
  - 判定归属：遇到“右边多一截”，先核对内部图元最大 `x`、右侧数值预留、图例/标题宽度与 `viewBox` 是否同一套参数算出；不要只靠增减 `max-width` / `margin` / `padding` 碰运气。

## 结论的时效性纪律

- 本文件与实测清单里的行为都钉在"最后验证版本"上（见 environment.md）。思源升级后先跑 `scripts/health_check.mjs`，漂移了再逐家族查 changelog / 回源码锚点，不要整库重读。
- 曾经发生过"旧结论是错的"的先例：`setBlockAttrs` 传空串一度被记为"删不干净"，2026-07-04 实测+源码确认能彻底删除——**发现结论错误时直接改写并删除旧文，不保留矛盾版本**。
