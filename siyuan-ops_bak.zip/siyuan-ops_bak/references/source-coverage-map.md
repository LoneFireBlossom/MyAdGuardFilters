# SiYuan Source Coverage Map

Use this file to answer one question fast: "what has already been read deeply enough, and what still needs more source or live verification?"

Snapshot baseline:

- reading snapshot date: 2026-07-04
- installed build context: `3.7.1-alpha.2`
- source trees used: local SiYuan shallow clone plus pinned sqlite driver clone

Evidence legend:

- `deep source-backed`: enough source has been read to operate the family with confidence, barring future drift
- `source-backed, still wants live probe`: semantics are clear from source, but at least one realistic local write/readback probe would still improve confidence
- `wrapper-level only`: we understand the outer API/tool shape, but have not read enough deep implementation to trust edge-case behavior blindly

## Deep source-backed

- blocks and transactions
  - `append/prepend/insert/update/move/delete/transferBlockRef/setBlockAttrs/getBlockKramdown`
- filetree and document lifecycle
  - doc create/create-with-md/daily-note/duplicate/rename/move/remove/doc-structure transforms
- file reads and workspace-bounded file writes
  - `getFile/readDir/renameFile/removeFile/putFile`
- asset upload and placement
  - upload target-dir resolution, dedupe, doc-near assets, explicit `assetsDirPath`
- tags, bookmarks, backlinks, outline, templates
  - multi-tree rewrite semantics plus rendered read surfaces
- SQL
  - HTTP vs CLI vs MCP safety differences, row-yielding write caveat, query-path limits
- notebooks and workspace
  - notebook mount/open/close/create/remove/conf writes
  - workspace registry vs physical deletion vs active workspace switch
- imports
  - `importSY/importData/importStdMd/importZipMd/ImportFromLocalPath`
- history and rollback
  - doc/assets/notebook/AV rollback, history indexing/search, explicit doc-history creation
- repository snapshots
  - snapshot read/diff/search/export/rollback/checkout mental model
- export/convert/network
  - export temp-path behavior, pandoc environment rules, SSRF-safe proxy/network helpers
- MCP layer
  - major built-in tools relevant to note operations, including `document/block/file/database/import/export/repo/history/sql/ref/tag/template/sync/workspace/bookmark/outline/system/unzip`
- AV family
  - render, values, filters, sorts, groups, layouts, views, relations, rollups, templates, cleanup, history/snapshot render

## Source-backed, still wants live probe

Ordered roughly by value; this section is the only home for open probe/reading priorities.

- import branch coverage
  - core import paths are read, and local probes cover frontmatter attr/title behavior plus folder-placeholder and imported-link rewriting semantics
  - richer end-to-end probes are still useful after future upgrades, especially for `importZipMd` and larger mixed-asset folder trees
- SQL write-path edge
  - a fully harmless row-yielding write case would tighten the SQL note beyond PRAGMA (also the open TODO probe in `scripts/health_check.mjs`)
- newly introduced `av/*` write APIs
  - anything added after the 2026-07-04 reading snapshot starts unclassified — probe narrowly per W2 discipline before batch use
- MCP-vs-HTTP-vs-CLI convergence points
  - re-check when the local environment changes (e.g. an MCP surface becomes actually usable in the current agent host)
- pandoc-backed export
  - source and one local reachability check exist; a richer end-to-end probe is still useful whenever the local pandoc environment changes
- low-priority helper surfaces
  - `emojis`, external web helpers, thin UI/runtime wrappers — operational but not note-data critical

Closed since the 2026-07-04 snapshot (all live-tested; see [verified-behaviors.md](./verified-behaviors.md)): `renameAsset` full chain including AV `MAsset`/`URL` rewrites; repo per-file rollback for plain files, `.sy`, and AV JSON; native merged-cell table writes via `dataType=dom`.

## Wrapper-level only or low-priority

- thin runtime/agent helpers
  - `todo_write`, `question`, `frontend`, skill persistence, plugin/petal loading
  - now source-read enough to classify confidently; still low priority because they are runtime surfaces rather than note-data semantics
- small MCP helpers
  - `emojis`, external `web_search`, some utility-only wrappers
  - now wrapper/source-read enough for correct routing; low priority unless a future workflow depends on them

## Where to reopen source after drift

The drift procedure itself lives in [SKILL.md](../SKILL.md) ("Drift protocol" — the only authoritative copy); run it first. When it points at a family that needs source re-reading, use this map rather than rereading the whole tree.

Recommended family-to-file map:

- blocks/filetree/attrs: `kernel/model/transaction.go`, `kernel/model/file*.go`, `kernel/api/block.go`, `kernel/api/filetree.go`
- imports/history/repo: `kernel/model/import.go`, `kernel/model/history.go`, `kernel/model/repository.go`
- assets/files: `kernel/model/assets.go`, `kernel/model/upload.go`, `kernel/api/file.go`
- AV: `kernel/model/attribute_view*.go`, `kernel/model/av/*.go`, `kernel/sql/av*.go`, `kernel/av/*.go`
- notebook/workspace/sync: `kernel/model/box.go`, `kernel/model/mount.go`, `kernel/api/workspace.go`, `kernel/model/sync.go`
- export/network/pandoc: `kernel/model/export.go`, `kernel/api/export.go`, `kernel/api/network.go`, `kernel/util/pandoc.go`
- MCP: `kernel/mcp/tools/*.go` plus the corresponding `kernel/model/*` or `kernel/api/*` backing path

## Maintenance note

This file is only the map. Deep conclusions belong in:

- [core-source-notes.md](./core-source-notes.md)
- [av-source-notes.md](./av-source-notes.md)
- [api-classification.md](./api-classification.md)
- [api-operation-rules.md](./api-operation-rules.md)

If this map and the deep notes disagree, fix the deep notes first, then sync this summary.
