# Live-Verified Behaviors (this machine)

本机实测行为清单。每条有一个稳定 slug（加粗首词）、日期、验证版本和**自证探针**——不确定某条是否仍然成立时，跑探针，别信文本。

- `scripts/health_check.mjs` 是本清单的自动化版本：**探针函数名 = 条目 slug**（未覆盖的条目见各条探针描述，用时现场跑）。
- 引用某条结论时用 slug（如 `asset-rename-full-chain`），不要用序号——序号会随增删漂移，slug 不会。
- 全部条目：live-tested **2026-07-04**，build **3.7.1-alpha.2**，除非另注。

## 文档与块

- **callout-native-parse** — `createDocWithMd` 原生解析 callout：`> [!EXAMPLE] 例题` → `NodeCallout`（CalloutType=EXAMPLE, CalloutTitle=例题）；纯 `> 引述` 保持 `NodeBlockquote`。
  探针：建临时文档含上述两种块 → 读 `.sy` 检查 `Type` 字段。
- **custom-doc-id** — `createDocWithMd` 接受自定义 `id`：payload 加 `"id":"20250104190920-abc1234"` → 返回该 ID，文档创建时间随 ID 前缀。
  探针：带 id 建文档 → 比对返回值 → `getBlockAttrs` 看 id。
- **empty-doc-append-fill** — 空文档 + `appendBlock` 多块填充：`parentID`=文档 ID、`dataType`=markdown、多块内容（标题/段落/表格/callout）一次写入，全部正确成块。注意 `createDocWithMd` 传空 markdown 会留一个空段落块。
  探针：空文档 append 多块 → `.sy` 数块。
- **insertblock-previousid-next-sibling**（2026-07-05）— `insertBlock` 的 `previousID` 确实表示“插到这个块后面”：在同一父块下写入 `dataType=dom` 的 HTML 块后，`getChildBlocks(parentID)` 能立即看到它成为目标块的下一个兄弟。注意不要用 SQL `ORDER BY created` 来验证这个相邻关系；那不是块树顺序面。
  探针：建临时父容器（列表项或文档）含两个已知子块 → 对前一个子块调用 `insertBlock {previousID:<id>, dataType:"dom"}` → `getChildBlocks(parentID)` 核对顺序。
- **ref-embed-passthrough** — `((id "锚文本"))` 与 `{{select}}` 经 `createDocWithMd` 直写成立：kramdown 回读可见 block-ref span 与嵌入块。前提是目标 ID 已存在——先建目标、后写引用。
  探针：建文档写两种语法 → `getBlockKramdown`。
- **doc-attrs-set-remove** — `setBlockAttrs` 对文档块写 `tags`（含层级 `a/b`）/`alias`/`custom-*` 全部生效；空串删除属性同时清掉属性索引与 kramdown IAL（与同日源码结论一致）。
  探针：set → `getBlockAttrs` → set 空串 → 再读。
- **inline-font-span-escaped**（2026-07-05）— 普通正文里写入行内 `font-family` 不生效：`<span style="font-family: Georgia">...</span>` 经 `createDocWithMd` 写进普通段落后被转义成字面文本显示。思源支持编辑器级全局字体，但不把 HTML 行内字体样式当正文原生能力（应对方案见 format-and-blocks.md）。
  探针：建临时文档写入带 `font-family` 的 span → `getBlockKramdown` 看是否仅剩字面文本 → `getDoc` 看渲染是否为转义文本。
- **html-block-multiline-only**（2026-07-05）— 原始 HTML 是否落成 `NodeHTMLBlock` 和"是不是单行"强相关：多行且独占一段的 `<div>...</div>` 经 `createDocWithMd` / `appendBlock(dataType=markdown)` 稳定落成 `NodeHTMLBlock`；紧凑单行 HTML 容易退化成 `NodeParagraph`。
  探针：同一模板做"多行版"和"单行版"最小文档 → 读 `.sy` / `getDoc` 比对块类型。
- **svg-update-markdown-splits**（2026-07-05）— 多行 SVG 直接走 `updateBlock(dataType=markdown)` 不可靠：思源可能把前半段保成 `NodeHTMLBlock`，后半段拆成多段被转义的 `NodeParagraph`，不是完整单块替换。稳妥路线是 `dataType=dom`（见 format-and-blocks.md HTML/SVG 节）。
  探针：准备单个 HTML 块 → `updateBlock(dataType=markdown)` 写多行 SVG → `getDoc` / SQL 查相邻块是否出现转义的 `<g> / <text> / <rect>` 段落。
- **svg-viewbox-overflow**（2026-07-05）— 图表 SVG"右侧长出来"可由 `viewBox` 与内部坐标不一致直接导致：外层已 `width:100%`，但内部最右元素超出 `viewBox` 宽度时仍会溢出。"外层自适应"不等于"内部边界闭合"。
  探针：先只改外层 `width/max-width`，再单独核对内部最大 `x` 与 `viewBox`；只改容器无效、统一内部坐标后恢复 = 命中此条。

## 表格

均 live-tested **2026-07-05**（本机 3.7.1）。结构事实的正式版在 format-and-blocks.md 表格节；操作流程在 recipes.md Recipe 3。

- **table-dom-append-native-merge** — 原生合并单元格表格可经块 API `dataType=dom` 写入：`appendBlock` 写完整 `NodeTable` DOM 后，`.sy` 生成原生 `NodeTable`，保留 `NodeTableCell.Properties.colspan/rowspan` 与被覆盖格 `class="fn__none"`。
  探针：从现有原生合并表格 `getDoc` 抽整块 DOM → 新建临时文档 → `appendBlock {dataType:"dom"}` → 读 `getDoc` 与 `.sy` 检查 `NodeTable` / `colspan` / `rowspan` / `fn__none`。
- **table-dom-update-para-to-table** — `updateBlock {dataType:"dom"}` 可把普通段落原地改写成原生合并表格：渲染层出现 `data-type="NodeTable"`，落盘 `.sy` 保留原生合并结构。
  探针：health_check 同名探针；或建单段落临时文档 → `updateBlock {dataType:"dom"}` 写表格 DOM → 读 `getDoc` 与 `.sy`。
- **table-md-html-not-native-merge** — Markdown 管道表 / 原始 HTML `<table>` 不是原生合并单元格的可靠写法：`{: colspan=...}` 会变字面文本；`<table rowspan/colspan>` 只作为普通 HTML 存在，不落成 `.sy` 的 `NodeTableCell.Properties + fn__none` 结构。
  探针：对同一目标表分别试 `dataType=markdown` 与普通 HTML → 比对 `.sy` 是否出现原生合并结构。

## 资产

- **assets-direct-cp-referencable** — 直接 `cp` 文件进 `data/assets` 可被引用；含空格/中文的文件名，原样与 URL 编码两种写法都能存进 `NodeLinkDest`。（渲染层对未编码空格的兼容性未逐一验证，批量写入建议统一 URL 编码。）
  探针：写 1px PNG 进 assets → 建文档两种引用 → `.sy` 收集 `NodeLinkDest`。
- **assets-sql-table** — `assets` SQL 表记录每处资产引用：`block_id` / `root_id` / `path` / `name` / `hash`，题头图也在内（`title` 字段值 `title-img`）。是资产引用审计的首选面。
  探针：`SELECT * FROM assets LIMIT 5`。
- **asset-rename-full-chain** — `renameAsset` 全链路（含关键语义）：参数是 `{oldPath, newName}`——**不是** `newPath`（传错键名返回 code 0 但什么都不做，危险的假成功）。`newName` 是不含扩展名的显示名；内核自动追加 `-时间戳-随机串` 并**保留原扩展名**（newName 里写 `.jpeg` 会被当作名字的一部分）→ **此 API 无法改扩展名**。响应 `data.newPath` 给出最终路径。普通块的 `![](assets/...)` / `[link](assets/...)` 引用与 `.sy` 会被内核同步重写；`title-img` 也会在 kramdown、`.sy`、`assets` SQL 中改成新路径，但同一时刻 `getBlockAttrs` 仍可能暂时返回旧值（见 runtime-quirks.md）。AV 侧改写见下面两条。
  探针：health_check 同名探针；或手动建引用文档 → rename → `getBlockKramdown`。
- **asset-rename-av-masset** — `renameAsset` 会重写 AV 的 `MAsset` 列内容：目标格 `mAsset[].content` 改成新路径，旧路径消失。注意 `mAsset[].name` 不会自动改成内核生成的新文件名，仍保留设置该单元格时写入的显示名。
  探针：复制示例数据库块 → `setAttributeViewBlockAttr` 写一格 `MAsset` → `renameAsset` → 读 AV JSON。
- **asset-rename-av-url** — `renameAsset` 也会重写 AV 的 `URL` 列中指向 `assets/...` 的值：目标格 `url.content` 改成新路径，旧路径消失。
  探针：复制示例数据库块 → `addAttributeViewKey(keyType=url)` → `setAttributeViewBlockAttr` 写 `url.content=assets/...` → `renameAsset` → 读 AV JSON。
- **asset-remove-unused-history** — `removeUnusedAsset` 会先写 cleanup history 再删除：删掉最后一个引用文档后资源出现在 `getUnusedAssets`；调用 `removeUnusedAsset` 后文件消失，同时在 `history/<timestamp>-clean/assets/<filename>` 留副本。
  探针：建临时文档引用资源 → 删文档 → `getUnusedAssets` 命中 → `removeUnusedAsset` → 检查 `history/*-clean/assets/`。
- **asset-endpoints-mounted** — 其余资产端点存在性（空 payload 探测非 404）：`getUnusedAssets`、`getMissingAssets`、`getDocImageAssets`。仅证明挂载，完整语义未逐一验证。
  探针：health_check 同名探针（`getMissingAssets` 形状检查）。

## 数据库（AV）

- **av-write-paths-minimal** — AV 关键写入口已具备最小本机验证：至少跑通过 `setAttributeViewBlockAttr`、`addAttributeViewKey`、`duplicateAttributeViewBlock`、`removeUnusedAttributeView` 这些真实写/清理路径；`renderAttributeView`、`getAttributeView`、`getAttributeViewKeys`、`/api/transactions` 也做过空 payload 非 404 挂载确认。⚠ 这不代表整个 `av/*` 家族都可以无脑批量调用；首次碰到新的 AV 写类型，仍按 W2 纪律先做窄探针。

## 导入

- **import-frontmatter-custom-attrs** — `importStdMd` 的 YAML frontmatter 不是"id/updated 直灌根块"：`title` 成为真正的文档标题；`id` / `updated` 分别落成根块属性 `custom-id` / `custom-updated`；实际根块 `id/updated` 由导入时新生成的值决定。
  探针：写临时 Markdown，frontmatter 含 `id/title/updated` → `importStdMd` 到 `/` → 读 `getBlockAttrs` 与 `getBlockKramdown`。
- **import-folder-placeholder-links** — `importStdMd` 文件夹导入会创建"根文件夹占位文档"，并把相对 `.md` 链接转成思源内部链接：文件夹本身变成同名根文档；含 Markdown 的子文件夹变成同名占位文档；相对 `.md` 链接不保留字面 `.md`，改成内部文档链接（probe 中见过 `((id "锚文本"))` 和 `[[../note|Back To Note]]` 两种形态）；frontmatter 的 `tags` 落成真正的根块 `tags`，`lastmod` 驱动根块 `updated`。
  探针：建临时本地目录树 → `importStdMd` 导入 → SQL 查文档层级 → `getBlockKramdown` 看链接形态与 attrs。
- **import-same-name-folder-md** — 文件夹导入里，"同名文件夹 + 同名 Markdown 文件"不是"跳过文档"，而是"用该 Markdown 内容填充同名文件夹文档"：`duo/` 旁若有 `duo.md`，最终得到标题为 `duo` 的文档，承载 `duo.md` 的内容，同时 `duo/child.md` 仍导入为其子文档。
  探针：建 `duo/child.md` + 同级 `duo.md` → `importStdMd` → SQL 查标题层级 + `getBlockKramdown(duo)`。

## 仓库（Repo）

repo 单文件 diff/rollback 的三个分支均已验证可用，共同模式：`diffRepoSnapshots(left, right)` 给出同一路径两侧不同 `fileID` → `openRepoSnapshotFile(fileID)` 读内容区分版本 → `rollbackRepoSnapshotFile(旧版 fileID)` 恢复。

- **repo-file-rollback-plain** — 普通文件/资产分支：`openRepoSnapshotFile` 直接返回文本内容；rollback 后磁盘文件恢复旧版。
  探针：写工作区探针文件 A → snapshot → 改成 B → snapshot → diff → open 两侧 fileID → rollback 旧版 → 读磁盘。
- **repo-file-rollback-sy** — `.sy` 文档分支：`openRepoSnapshotFile` 返回渲染后的 BlockDOM，可区分版本；rollback 后 `getBlockKramdown` 恢复旧版。注意同轮 probe 里 `getBlockAttrs.updated` 仍可能停留在较新值，回滚后优先信 `getBlockKramdown` / `.sy`（见 runtime-quirks.md）。
  探针：建临时文档 A → snapshot → 改成 B → snapshot → diff → open 两侧 fileID → rollback 旧版 → 读 kramdown。
- **repo-file-rollback-avjson** — AV JSON 分支：`openRepoSnapshotFile` 对 `data/storage/av/*.json` 返回纯 JSON 文本（不是渲染面）；rollback 后磁盘 AV JSON 恢复旧版，可直接以磁盘 JSON 为准确认。
  探针：复制示例数据库 → 直改 AV JSON 为 A → snapshot → 改为 B → snapshot → diff → open 两侧 fileID → rollback 旧版 → 读磁盘 JSON。

## 已知边界

- `renameAsset` 在 AV 里更怪异的派生显示面（例如某些已渲染卡片缓存）是否也同步刷新，尚未专门做 UI 级 probe；当前已验证的是 AV JSON 持久层值。
- MCP 面在 Codex 会话中注册未成功（见 environment.md）；Claude 侧未试。
- 以上不覆盖 `moveBlock`/`deleteBlock`/`transferBlockRef` 等 W2 块结构写的本机验证——用到时现场探针。
