# SiYuan Block Shapes and Markdown Forms

写内容进思源之前读这个：块形态的结构性事实 + markdown 语法在思源里的形态。项目专属的内容规范（例题结构、心法链接规则）在 exam-notes skill，不在这里。

## Callout vs blockquote

- 原生 callout 是 `NodeCallout`（带 `CalloutType` / `CalloutTitle`），纯引述是 `NodeBlockquote`。渲染相似 ≠ 结构等价；验证要看 `.sy` 或块树，不能只看渲染。
- **live-tested 2026-07-04（3.7.1-alpha.2）**：`createDocWithMd` / `appendBlock` / `updateBlock` 里的 `> [!TYPE] 标题` 会直接解析为 `NodeCallout`；`> [!TYPE]-`（Obsidian 折叠语法）思源不支持折叠标记。
- 内置类型（NOTE/TIP/WARNING/IMPORTANT 等）不依赖主题；自定义类型（如本项目的 EXAMPLE）靠主题/插件样式，做官方行为复现实验时先用内置类型。

## 列表项是容器块

- 一个 `NodeListItem` 可以容纳多个段落、表格、图片、数学块和嵌套列表——这是思源块模型的关键能力。
- 把"一道题"建模成一个列表项容器（内含多块）与建模成"一行列表 + 一堆兄弟块"是完全不同的结构；写入和修复时必须明确选择哪种。

## 块引用与嵌入

- 静态锚文本：`((块ID "锚文本"))` —— 锚文本固定。
- 动态锚文本：`((块ID '锚文本'))` —— 跟随原文更新（上限 5120 字符）。
- 嵌入块：`{{select * from blocks where id='块ID'}}`。
- **live-tested 2026-07-04**：两种形态经 `createDocWithMd` 直写均成立（kramdown 回读确认），前提是目标 ID 已存在——先建目标、后写引用。
- 表格单元格内的块引用同样可用；`data-subtype="s"`=静态、`"d"`=动态。

## 表格

- 思源给所有表格自动生成 `colgroup` 属性：管道分隔的 CSS 串，每段进 `<col style="...">`。裸值（如 `250px`）是无效 CSS 会被浏览器忽略，必须写完整键值对（`min-width: 250px`）。
- 列宽还受 markdown 分隔行破折号数量比例影响；重写表格时统一用 `| --- |` 避免意外比例分配。
- 表格自然宽度超容器会溢出（思源默认无 max-width）——已用全局 CSS 片段解决（见 environment.md）。
- **live-tested 2026-07-05（本机 3.7.1）**：当目标是**思源原生合并单元格表格**时，块写 API 的 **`dataType="dom"` 是应走的写入路线**；前提是喂进去的是完整的表格块 DOM，而不是只给一段 Markdown/HTML。关键结构信号包括：
  - 外层块是 `data-type="NodeTable"`。
  - 合并格直接带 `rowspan` / `colspan`。
  - 被覆盖的占位格保留为 `class="fn__none"`，这是原生结构的一部分，不是可省略的装饰。
- **live-tested 2026-07-05**：如果只走 Markdown 管道表或原始 HTML `<table>`，思源不会稳定地把它们提升成这种原生合并结构；验证标准要看 `.sy` / `getDoc` 里的 `NodeTable + fn__none + rowspan/colspan`，不要只看屏幕上像不像合并了。
- 实操上，`getDoc` 返回的 `content` 本身就是可复用的块 DOM 来源；要复制或替换一个复杂原生表格形态时，应先从现有原生表格抽 DOM，再用 `appendBlock` / `insertBlock` / `updateBlock` 的 `dataType="dom"` 回写，而不是回退到 Markdown/HTML 方案。

## Markdown 语法形态

- 标签：闭合形式 `#标签#`，支持层级 `#父/子#`。
- 行内数学 `$...$`、上标 `^`、下标 `~`：需要在 **设置 → 编辑器 → Markdown 语法** 里开启对应开关才渲染。
- 高亮 `==文本==`：原生支持。
- YAML frontmatter：编辑器不渲染为属性；导入路径（`importStdMd`）会读取 frontmatter 派生 ID/标题/更新时间（source-backed，见 core-source-notes 导入条目）。
- 软换行不是可靠的块边界信号；拆块时要同时处理 `NodeSoftBreak` 和 `NodeText` 里的字面 `\n`。
- **live-tested 2026-07-05（本机 3.7.1）**：普通正文内容不要假设支持“任意局部换字体”。把 `<span style="font-family: ...">...</span>` 之类 HTML 行内字体样式写进段落时，思源不会把它当成稳定的原生富文本字体能力；在本机实测里它会被当字面文本转义显示。
- 实操理解：
  - **支持/适合**：编辑器全局字体、主题/CSS 片段层面的整体字体控制。
  - **不适合默认指望**：像 Word 一样在同一篇普通笔记正文里随意让某几个字/某一段切换到另一种字体并稳定持久化。
  - 如果确实要在同页展示不同字体，更接近可行的路子通常是 HTML 块、挂件或主题/CSS 定向样式，而不是普通正文行内样式。

## 文档级属性

- 文档块支持 `title` / `tags`（逗号分隔，支持层级）/ `alias`（逗号分隔）/ `memo` / `bookmark` / `custom-*`。
- **live-tested 2026-07-04**：`setBlockAttrs` 对文档块写 tags/alias/custom-* 全部生效并可读回。
- 文档创建时间编码在文档 ID 前缀里；`createDocWithMd` 接受自定义 `id`，因此可以让"创建时间"语义完全受控（live-tested 2026-07-04）。

## HTML / SVG 块

- **live-tested 2026-07-05（本机 3.7.1）**：原始 HTML 不是“只要长得像 HTML 就一定进 `NodeHTMLBlock`”。同样是 `<div>...</div>`：
  - **多行、块级、独占一段**的原始 HTML，经 `createDocWithMd` 或 `appendBlock(dataType=markdown)`，可以稳定落成 `NodeHTMLBlock`。
  - **单行内联式** HTML 很容易退化成普通 `NodeParagraph`，而不是 HTML 块。
- 对图表类内容，普通 `updateBlock(dataType=markdown)` 也不要想当然地当成“整块 HTML/SVG 替换器”：
  - 当内容是较长的多行 SVG/HTML 片段时，思源可能只把前半段收成 `NodeHTMLBlock`，后半段拆成一串普通段落块。
  - 这种情况下，更稳的入口通常是：先确认最终目标就是 `NodeHTMLBlock`，再优先走 `dataType=dom` 回写完整 HTML 块 DOM，而不是把整段源码直接塞进 markdown 写面。
- 图表类 HTML/SVG 的“自适应”要分两层理解：
  - 容器层：`width:100%` 只能保证块跟随父容器缩放。
  - 内容层：真正的可视边界由 SVG `viewBox` 与内部坐标共同决定；如果内部元素的最右边界超出了 `viewBox`，即便外层是 `width:100%`，右侧也仍会“长出去”。
- 实操纪律：
  - 想验证是否真的是 HTML 块：看 `.sy` 或 `getDoc` 的 `data-type="NodeHTMLBlock"`，不要只看屏幕上像不像。
  - 想验证图表是否会溢出：不要只看外层 `width/max-width`；还要核对 SVG 内部元素的实际最大 `x` 坐标、标签/数值预留和 `viewBox` 宽度是不是同一套参数算出来的。
