# SiYuan API Classification (R / W1 / W2 / W3)

Load this file when choosing an API for a task and deciding what per-call discipline applies. Deep semantics live in [core-source-notes.md](./core-source-notes.md) and [av-source-notes.md](./av-source-notes.md); calling policy lives in [api-operation-rules.md](./api-operation-rules.md).

## Why this scheme (and what happened to A/B/C)

The predecessor classification (A/B/C in the exam-notes skill) graded **how much evidence was needed before trusting an API** — docs-only vs multi-scenario testing vs source reading. That job is finished: the relevant source has been read (snapshot 2026-07-04, build `3.7.1-alpha.2`).

What still matters per call is **blast radius and the verification discipline it demands**. So APIs are now graded by write depth:

| Tier | Meaning | Per-call discipline |
|---|---|---|
| **R** | Read-only (or trivially shallow side effects) | Call and trust the result shape. |
| **W1** | Additive/local content write; existing content untouched; IDs preserved | Verify by readback (`getBlockAttrs` / `getBlockKramdown` / file existence). |
| **W2** | Structural write: rewrites existing content, changes IDs, touches refs/bindings, or has no history net | Prefer the narrowest write. Multi-surface verify (kramdown + SQL + `.sy` as needed). First use on a new SiYuan build → probe in a scratch notebook first (or run `scripts/health_check.mjs`). Consider a repo snapshot before batches. |
| **W3** | Workspace-scale: bulk import, rollback, notebook/workspace lifecycle | Explicit user confirmation + snapshot mandatory + post-op audit. Never chain W3 calls without checking between them. |

Mapping from the old scheme (Codex's originals still use it): old `A类` ≈ R; old `B类` spread across R★/⚙/W1; old `C类` spread across W1 (creation) / W2 / W3.

Orthogonal flags used below:

- **★ nominal-read**: endpoint sounds read-only but can write (self-heal, temp materialization). Never use "it was just a render" as proof that nothing changed.
- **⚙ environment-sensitive**: correctness depends on external binaries, network policy, temp dirs — verify environment, not tree state.
- **🚫 no-history**: mutation with no automatic history backup; mistakes are only recoverable via repo snapshots.
- **⚠ drift-prone**: undocumented endpoint (not in `API.zh-CN.md`); no compatibility promise across versions. Re-probe after upgrades before relying on it.

## R — read-only

- `system`: `/api/system/version`, `/api/system/currentTime`, `/api/system/bootProgress`
- `notebook`: `/api/notebook/lsNotebooks`
- path lookup: `/api/filetree/getHPathByPath`, `getHPathByID`, `getPathByID`, `getIDsByHPath`
- block reads: `/api/block/getBlockKramdown` (strong verification surface), `getChildBlocks`; `/api/attr/getBlockAttrs`
- filetree reads: `listDocTree`, `listDocsByPath`, `getDoc`, `searchDocs`, `getDocCreateSavePath`, `getRefCreateSavePath`, `getShorthandSavePath` — note these are **state projections** (sort mode, hidden-doc filtering, publish filtering, render windows), not raw filesystem dumps
- file reads: `/api/file/getFile`, `readDir` (workspace-bounded; sensitive paths blocked for non-admin)
- SQL: `/api/query/sql` in its strictest mode — see the sql entry in core-source-notes: the default validation mode **can execute row-yielding non-readonly statements**, so for pure queries use the most restrictive mode available and never send write statements through this surface on purpose
- history reads: `searchHistory`, `getHistoryItems`, `getDocHistoryContent`
- refs and discovery: backlink/mention listing, `SearchTags`, `SearchTemplate`, MCP `system.*`, MCP `sync.status`
- outline and bookmark reads: `Outline`, `BuildBookmark`, `BookmarkLabels`
- cloud inbox reads: `GetCloudShorthands`, `GetCloudShorthand`
- repo reads ★: `GetRepoSnapshots`, `DiffRepoSnapshots`, `SearchRepoFile`, `OpenRepoSnapshotFile` (★ may materialize temp preview files)
- AV reads ★⚠: `renderAttributeView`, `getAttributeView`, `getAttributeViewPrimaryKeyValues`, `searchAttributeView`, `getAttributeViewFilterSort` — ★ because render paths can run spec upgrades, regenerate groups, create a missing AV (`createIfNotExist`), and **save during render**
- notification: `pushMsg`, `pushErrMsg` (visible UI message, no data mutation)
- template: `/api/template/render`, `renderSprig` (functional transforms)
- export ⚙: `exportMdContent` (in-memory render); `exportResources` / `/api/convert/pandoc` / `/api/network/forwardProxy` are ⚙ (temp outputs, external binary, SSRF policy) but not tree-mutating

## W1 — additive / local writes

- doc creation: `createDocWithMd`, `createDoc`, `createDailyNote` — additive, but path-aware: may create intermediate docs along the hpath; accepts a custom `id` (live-tested 2026-07-04); daily-note path comes from notebook conf
- block insertion into a known parent: `appendBlock`, `prependBlock`, `insertBlock` — the kernel reparses payloads, normalizes IDs, processes asset paths; existing blocks untouched
- attr layer: `setBlockAttrs` — empty string removes the attr from both the attr index and kramdown IAL (live-tested + source-backed 2026-07-04)
- fold state: `foldBlock`, `unfoldBlock`
- assets: `/api/asset/upload` (hash-dedupe + rename semantics; target dir resolution order — see core-source-notes)
- files: `/api/file/putFile` when creating a **new** file; overwriting an existing file is W2🚫 in spirit
- notebook shallow writes: `createNotebook`, `renameNotebook`, `setNotebookIcon`, `setNotebookConf` (conf changes alter future doc-creation/daily-note behavior)
- template file management: `CreateTemplate`, `DocSaveAsTemplate` when creating a new template file
- SQL: `flushTransaction` (queue flush, shallow)

## W2 — structural writes

- `updateBlock` — delete-then-insert semantics; **child block IDs change**; doc-level update replaces all top-level children
- `deleteBlock`, `moveBlock` (state-dependent special cases: folded headings, empty list items, superblocks), `transferBlockRef` (rewrites refs across referencing trees)
- filetree lifecycle: `renameDoc(ByID)`, `moveDocs(ByID)`, `removeDoc(ByID)` (history-backed but a whole doc tree disappears), `duplicateDoc`, `doc2Heading`, `heading2Doc`, `li2Doc`
- notebook lifecycle: `openNotebook`, `closeNotebook` (index/unindex, cache effects)
- asset maintenance: `/api/asset/renameAsset`, `removeUnusedAsset(s)` — both are structural maintenance writes; current source shows rename rewrites matching `.sy` trees plus AV JSON/OCR side data, and unused-asset removal snapshots into cleanup history before deletion
- file mutations 🚫: `renameFile`, `removeFile`, `putFile`-overwrite — workspace-bounded but **no history backup**
- tag maintenance: `RenameTag`, `RemoveTag` — rewrite tag marks / doc `tags` attrs across multiple trees, generate replace-history snapshots, and refresh affected AV block text
- bookmark maintenance: `RenameBookmark`, `RemoveBookmark` — rewrite block `bookmark` attrs across multiple trees and generate replace-history snapshots
- template removal / overwrite: `RemoveTemplate`, template overwrite paths
- workspace unzip: MCP `unzip` / archive extraction within the workspace — filesystem write with no note-structure history semantics; treat like a file mutation with broader blast radius than a read helper
- cloud inbox conversion: converting shorthands into local docs is at least W2, and W3 in batches — it creates local docs and can optionally delete cloud originals after success
- ALL `av/*` writes ⚠ (undocumented; model-global effects; see av-source-notes): cell updates (can cascade into options, two-way relations, bound-block attrs, group regen), row add/remove, key add/remove, filters/sorts (full replacement, not patch), groups, layout, view management, option editing, batch replace/update
- history: `rollbackDocHistory` (targeted but structurally rich; can create a `Rollback` notebook), `rollbackAssetsHistory`, `createDocHistory`
- repo: `RollbackRepoSnapshotFile` (auto-backups current state first)

## W3 — workspace-scale

- `removeNotebook` (data copied to history first, but a whole notebook goes away)
- import family: `importSY`, `importData` (full data overlay + `FullReindex`), `importStdMd`, `importZipMd` — bulk writes with ID regeneration and link rewriting
- history: `rollbackNotebookHistory` (full reindex), `rollbackAttributeViewHistory`, `clearWorkspaceHistory` (destroys the safety net itself)
- repo: `checkoutRepo` (repository-level state restore)
- sync: `SyncData`, `SyncDataUpload`, `SyncDataDownload` — workspace-wide cloud sync surfaces with provider/network/lock-state coupling
- agent/session utilities: `todo_write`, `question`, `frontend`, skill-install/save/remove/rename, plugin/petal loading — not core note-data APIs, but runtime/environment mutation surfaces; treat as W3 for operational caution when they change local runtime state or installed capabilities
- workspace: `createWorkspaceDir`, `removeWorkspaceDir` (registry-level), `setWorkspaceDir`, `removeWorkspaceDirPhysically` (☠ can delete the whole workspace and exit the process)
- `/api/transactions` (raw internal transaction surface — unbounded; use only with a specific, source-verified payload shape)

## Slotting rule for new/unlisted endpoints

1. Only reads → **R**; if it's a render/preview path, park it in the ★ watchlist until confirmed side-effect-free.
2. Adds new content without touching existing blocks → **W1**.
3. Rewrites existing content, moves/deletes, changes IDs, touches refs/bindings/AV state → **W2**.
4. Bulk/overlay/rollback/lifecycle of notebook-or-bigger → **W3**.
5. Not in `API.zh-CN.md` → add ⚠ regardless of tier.

## Evidence labels for notes (knowledge maintenance)

Separate from the call-time tiers above, every conclusion in the notes files carries one of: **doc-backed** (from official docs only), **live-tested** (verified on this machine's build — include the date), **source-backed** (read in kernel source — include the anchor). Escalate a conclusion's evidence level when a decision depends on it; after a SiYuan upgrade, re-verify per the drift protocol in [SKILL.md](../SKILL.md) instead of rereading everything.

## Source-reading priorities

Open probe/reading priorities live in [source-coverage-map.md](./source-coverage-map.md) — the only home for "what still needs source or live verification".
