# SiYuan API Operation Rules

This file is the practical calling guide for SiYuan operations on this machine: which surface to write through, how to verify, and the per-family safety defaults.

It deliberately contains **no deep semantics**. Every "why does it behave like this" fact has exactly one home in [core-source-notes.md](./core-source-notes.md) or [av-source-notes.md](./av-source-notes.md); this file links there instead of restating. (Rewritten 2026-07-05 from the 2026-07-04 exam-notes adaptation, which had duplicated the source notes wholesale.)

## Purpose split

- [api-classification.md](./api-classification.md) — tier classification (R/W1/W2/W3), per-tier discipline, evidence labels.
- [core-source-notes.md](./core-source-notes.md) / [av-source-notes.md](./av-source-notes.md) — deep source-backed semantics per API family.
- This file — operational choices: surfaces, verification, escalation, per-family safe defaults.

## Operating surfaces

- **HTTP API / Kernel CLI** — primary write surfaces (both reach the same running kernel).
- **`.sy` files** — primary verification surface.
- **Built-in MCP** — optional surface; treat as real only when the current session actually exposes usable SiYuan MCP tools.

MCP is **not** "HTTP with another transport": tools are hand-shaped adapters that may be narrower, add extra validation, or package different model calls (e.g. `workspace` is read-only, `document.create` won't create intermediate hpath docs, `import` bypasses HTTP staging checks). Before assuming HTTP/CLI/MCP parity for a task, check the MCP entry in [core-source-notes.md](./core-source-notes.md#built-in-mcp-layer).

## Default write policy

- Prefer writing through a running SiYuan kernel.
- Treat direct external `.sy` edits as forbidden by default, not as a normal fallback.
- Do not switch to `.sy` writes just because API/CLI/MCP feels awkward, a repair looks urgent, or the structure is already understood from inspection.
- Consider direct `.sy` writes only when all of these are true:
  - normal kernel-facing paths have been retried seriously enough to establish that they are not working for the current goal
  - the remaining target really cannot be completed through the running kernel surfaces
  - the user has been told exactly why `.sy` is being considered and has explicitly approved it in advance
- Treat local `SiYuan-Kernel` CLI as operationally acceptable when it reaches the same running kernel behavior and is more reliable than direct localhost HTTP in the current environment.

## Default verification policy

After meaningful writes, verify at the right layer, in this order:

1. API response success
2. Target block/document lookup
3. `getBlockKramdown` or equivalent block/document readback
4. `.sy` structural inspection when structure fidelity matters
5. Render/UI confirmation only after persistence is already believable

Do not trust search/index freshness as the first confirmation surface after writes ([runtime-quirks.md](./runtime-quirks.md) catalogs the known read-surface lags).

## Evidence ladder

1. `API.zh-CN.md` for the public contract
2. Local live verification against the installed SiYuan build
3. Targeted source reading for risky or semantically rich operations

Do not collapse these three into one. For a **new or newly changed** endpoint, escalate by risk: docs plus one probe suffice for read-only, low-ambiguity calls; multi-scenario probes when workspace state / indexing timing / file paths can change the outcome; source reading is mandatory once the call writes, moves, rebuilds, re-IDs, touches refs/bindings/AV state, or will be repeated often enough that misunderstanding is costly. (For already-covered families this job is done — see [source-coverage-map.md](./source-coverage-map.md).)

## How to record source evidence

- When source reading materially changes how we operate an API, record: the conclusion, the API name, the source file path, and enough function-level context to relocate it quickly ("observed in `kernel/model/transaction.go` insert path" is enough). Exact line numbers only when unusually useful.
- Record source anchors in the source-notes files, not in workflow text.
- If a note is based only on docs plus live verification, do not pretend it is source-backed — evidence labels are defined in [api-classification.md](./api-classification.md#evidence-labels-for-notes-knowledge-maintenance).

## Version drift

Follow the drift protocol in [SKILL.md](../SKILL.md) ("Drift protocol" section) — it is the only authoritative copy. Short form: stop writes, run `health_check.mjs`, re-verify only the drifted family via its source anchor, rewrite (don't append) the affected notes.

## Safe defaults by API family

Each subsection: operational discipline only; semantics live at the linked entry.

### Document creation and filetree writes

Semantics: [core-source-notes.md → Filetree and documents](./core-source-notes.md#filetree-and-documents).

- Do not treat `createDoc(WithMd)`, `createDailyNote`, `duplicateDoc` as lightweight helpers — creation is path- and workspace-aware and may create intermediate docs along the hpath.
- Verify placement by path lookup (`getPathByID` / `getHPathByID`) plus on-disk structure, not by title/search alone.
- When same-name parent docs are possible and placement looks wrong, inspect hpath ambiguity and any explicit `parentID` before suspecting the API.
- Remember `duplicateDoc` intentionally strips AV binding attrs and flashcard attrs from the copy.
- When a filetree write appears to "half succeed", inspect both the `.sy`/child-dir filesystem result and the tree/index/ref-refresh side effects.

### Import operations

Semantics: [core-source-notes.md → Import](./core-source-notes.md#import).

- Do not treat any import endpoint as "createDocWithMd in bulk" — imports regenerate IDs, synthesize placeholder docs, move assets, and rewrite links in later whole-batch passes.
- Verify in this order: import success response → expected notebook/path presence → target tree/doc lookup → `.sy`/asset verification when fidelity matters → search only after indexing settles.
- When imported placement or links look wrong, check: final `HPath`/real `.sy` path; whether the source lived under an `assets/` folder; placeholder-vs-content-doc expectations; whether frontmatter changed title/ID/updated/tags.
- Source-path policy failures happen **before** any import: importing from under the working dir or from sensitive local paths is refused at the API layer. MCP `import` does not inherit those HTTP wrapper checks.

### File and asset operations

Semantics: [core-source-notes.md → Files and assets](./core-source-notes.md#files-and-assets).

- Treat `file/*` as workspace-governed operations, not arbitrary filesystem access; path validation and sensitive-path refusal matter as much as the nominal action.
- For uploads, identify which targeting path is in play (global `data/assets` / document-near via `id` / explicit `assetsDirPath`) and verify the real resulting relative path, not just API success.
- For `renameAsset`, never trust a single read surface — `getBlockAttrs` can lag behind kramdown/`.sy`/SQL ([runtime-quirks.md](./runtime-quirks.md)); AV-side rewrite coverage is per-column (see `asset-rename-av-*` in [verified-behaviors.md](./verified-behaviors.md)).
- `refuse to copy sensitive file` means the **source** path hit the sensitive-prefix guard — change the source path before doubting assets/import logic.

### SQL access

Semantics: [core-source-notes.md → SQL](./core-source-notes.md#sql).

- HTTP `/api/query/sql`, CLI `sql`, and MCP `sql` are **not** equivalent safety surfaces: HTTP default mode can execute row-yielding non-readonly statements; CLI and MCP enforce single-statement readonly.
- For long-term automation, prefer the stricter CLI/MCP mental model; use HTTP-only behavior only when a workflow needs it and it has been locally tested.
- For pure queries through HTTP, use the most restrictive mode available and never send write statements through this surface on purpose.

### Notebook operations

Semantics: [core-source-notes.md → Notebooks and workspace](./core-source-notes.md#notebooks-and-workspace).

- Rename/icon are shallow conf writes; `setNotebookConf` is medium (changes future doc-creation/daily-note behavior); create/open/close/remove are stateful workspace operations with indexing, history, and cache side effects.
- After the heavier four, verify more than the return code: notebook list/open state, expected directory presence/absence, and whether indexing has settled if the workflow depends on it.

### Export, convert, and network

Semantics: [core-source-notes.md → Export, convert, network](./core-source-notes.md#export-convert-network).

- These are ⚙ environment-sensitive rather than tree-mutating: verify temp output locations, workspace path validation, external binary availability, and SSRF/network policy — not tree state.
- Before depending on pandoc-backed formats, check the binary first (`IsValidPandocBin` rejects scripts and fake binaries).
- Distinguish in-memory exports (`exportMdContent`) from temp-file exports (`exportResources` and friends); verify returned temp paths and export-config dependence.
- On this machine, local proxy tooling can intercept what looks like a localhost call — prefer Node fetch and see [environment.md](./environment.md) for the curl bypass.

### Workspace operations

Semantics: [core-source-notes.md → Notebooks and workspace](./core-source-notes.md#notebooks-and-workspace).

- Workspace APIs are environment-management surfaces, not note-content surfaces; the dangerous distinction is **registry removal ≠ physical deletion** (`removeWorkspaceDirPhysically` can delete the whole workspace and exit the process).
- "Switch workspace" rebuilds derived dirs, DB paths, and temp env — treat it as a runtime migration, not a config edit.
- MCP `workspace` is intentionally list/info only.

### History and rollback

Semantics: [core-source-notes.md → History and repository](./core-source-notes.md#history-and-repository).

- Rollback blast radius varies a lot — doc (targeted, may create a `Rollback` notebook), assets (direct file restore), notebook (full reindex), AV (JSON restore + cache clear). Pick the narrowest one that fits.
- After rollback, verify target presence **and** whether indexes/caches refreshed; give AV/ref state a second readback.
- History search is backed by a dedicated history DB — if search and on-disk history disagree, consider reindexing history before assuming a snapshot is missing.
- `clearWorkspaceHistory` destroys the safety net itself and is intentionally long-running — don't mistake the early wait for a hang.
- MCP `history.rollback` is document-only.

### Repository snapshots

Semantics: [core-source-notes.md → History and repository](./core-source-notes.md#history-and-repository).

- Repo ≠ history: repo depends on a configured `Conf.Repo.Key` / Dejavu repository and fails before any history-style logic when absent.
- `RollbackRepoSnapshotFile` auto-creates a backup snapshot of current data first; all three per-file branches (plain file / `.sy` / AV JSON) are live-tested — see `repo-file-rollback-*` in [verified-behaviors.md](./verified-behaviors.md).
- Snapshot open/diff/search are snapshot-view surfaces, not live-workspace reads; `checkoutRepo` is repository-level state restore (W3).

### Tags, bookmarks, templates, backlinks

Semantics: [core-source-notes.md → References, tags, and templates](./core-source-notes.md#references-tags-and-templates).

- Tag and bookmark rename/remove are multi-tree rewrites that snapshot into replace-history first — W2 discipline, not cosmetic label edits.
- Template save/render flows are document-tree aware; MCP template paths are confined to `data/templates`.
- Backlink/mention/outline/bookmark listings are rendered projections over live state; `RefreshBacklink` is real ref-index maintenance, not a UI refresh.

### Sync

Semantics: [core-source-notes.md → Sync](./core-source-notes.md#sync).

- Treat sync as W3 despite the small callable surface: correctness depends on provider validity, network, and the global sync lock, and the blast radius is workspace-wide runtime state.
- Do not chain sync with other destructive operations without checking between steps.

### Cloud inbox and runtime utilities

Semantics: [core-source-notes.md → Cloud inbox and agent/runtime utilities](./core-source-notes.md#cloud-inbox-and-agentruntime-utilities).

- MCP `inbox.convert` is a composed workflow (cloud read → local doc create → optional cloud delete); for batches verify both sides explicitly.
- `todo_write` / `question` / `frontend` / skill management mutate session/runtime capability state, not note data — don't confuse the two, but treat capability changes with W3-level caution.
- MCP `unzip` is a generic workspace file write with no note-history semantics.

### Filetree read helpers

Semantics: [core-source-notes.md → Filetree and documents](./core-source-notes.md#filetree-and-documents).

- Filetree "reads" are state projections (sort mode, hidden-doc and publish filtering, render windows), not raw filesystem dumps; `getDoc` is a render pipeline that flushes tx first.
- Save-path helpers (`getDocCreateSavePath` etc.) are config-and-template evaluations — verify notebook-specific overrides when placement matters.

### Block writes

Semantics: [core-source-notes.md → Blocks and transactions](./core-source-notes.md#blocks-and-transactions).

- `insert`/`append`/`prepend`/`move`/`delete` operate on the real tree; special cases abound (folded headings, empty list items, superblocks).
- `updateBlock` is delete-then-insert: child block IDs change and behavior differs by target type — treat it as the most dangerous routine write ([runtime-quirks.md](./runtime-quirks.md) has the repair-lesson list).
- Prefer the narrowest write that accomplishes the task.

### Block attrs

- Use `setBlockAttrs` for true attribute-layer changes; never reach for `updateBlock` just to change attrs.
- Re-verify through both `getBlockAttrs` and kramdown when the distinction matters.

### Attribute views (databases)

Semantics: [av-source-notes.md](./av-source-notes.md) — load it for any AV task.

- Treat every `av/*` write as an AV-model mutation: a single call may touch stored JSON, multiple views, groups, bound block attrs, mirror blocks, and related AVs. Before calling, classify it: current-view-only / AV-global / cross-AV.
- Cell updates are the deepest path — they can create options, maintain two-way relations, and (for primary keys) perform binding-state surgery on the target block.
- Render calls are not guaranteed passive: they can spec-upgrade, regenerate groups, create missing AVs, and save during render. Never prove "no write happened" from an endpoint being named `render*`.
- Template/rollup values are late-bound render products — debug output mismatches by inspecting the relation source field and destination AV, not just the local row.
- "Odd" sort/filter results are often correct under option-order, edited-vs-unedited partitioning, or relative-time semantics — check those before filing a bug.
- Cleanup endpoints are graph-aware and history-producing, not cosmetic; "unused" considers indirect relation references.
- Distinguish the visible `NodeAttributeView` block ID from the underlying `AttributeViewID`; wrapper argument names are not harmonized (`removeUnusedAttributeView` wants `id`, duplicate wants the real `avID`).
- MCP `database` is a curated subset but routes into the same deep mutation paths.

## Questions to ask before using a write API

1. Does this write touch only one block, or can it affect children, mirrors, groups, or related AVs?
2. Does it preserve IDs, or can it regenerate/rebind them?
3. Is this really an attr change, or is it secretly a content/tree rewrite?
4. Which verification surface will reveal the truth fastest: API readback, block kramdown, or `.sy`?
5. Is the current surface choice robust in this environment: HTTP, CLI, or MCP?
6. For AV work, is this operation actually current-view-local, or does it also mutate AV-global state, mirror attrs, options, groups, history, or related AVs?

## What not to do

- Do not treat successful HTTP return codes as enough proof of structural correctness.
- Do not rely on search freshness as a primary post-write confirmation.
- Do not assume a simple endpoint name implies simple semantics.
- Do not assume built-in MCP is usable just because SiYuan exposes an MCP route in principle.
- Do not default to direct `.sy` edits when the running kernel can perform the write. "Recovery", "one-off repair", or "I can already see the exact `.sy` shape" are not by themselves valid reasons to cross this boundary.

## What to report after risky operations

After a W2 or W3 write, report:

- which surface was used: HTTP API, Kernel CLI, or another verified path
- what was changed
- what was used to verify it
- whether any semantics are still only source-inferred or still awaiting local verification
