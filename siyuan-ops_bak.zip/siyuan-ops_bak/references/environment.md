# Environment (this machine)

本机思源环境参数的唯一权威来源。其他文档一律引用这里，不要复制数值。

## 核心参数

- **Workspace**: `/Users/lonefireblossom/Documents/Mooncell/Mooncell-SiYuan`
- **Data root**: `/Users/lonefireblossom/Documents/Mooncell/Mooncell-SiYuan/data`
- **API base**: `http://127.0.0.1:60207/api`
- **Kernel CLI**: `/Applications/SiYuan.app/Contents/Resources/kernel/SiYuan-Kernel`
- **Built-in MCP URL pattern**: `http://127.0.0.1:60207/mcp?token=<token>`
- **最后本机验证版本**: `3.7.1`（2026-07-05，health_check 9/9 PASS；此前为 `3.7.1-alpha.2`。本机更新通道偏 alpha、漂移频率相对高——升级后先跑 `scripts/health_check.mjs`）

## 笔记本

- `20260703190408-xa3dc4z` — **Official**（主笔记本，含 `/心法`、`/资料分析`）
- `20230918122411-88b39g5` — daily notes（2023 年旧笔记本，关闭状态，约 109 篇，暂不处置）

## 本机多内核现状（2026-07-05／07-06，live-tested）

- 桌面端每次启动主工作区都会分配一个**新的随机端口**（07-05 见过 `60207`，07-06 见过 `53762`），端口号本身不可预测，不要硬编码。
- `6806` 是思源给浏览器剪藏扩展等外部工具准备的**固定端口候选**，但**不保证每次都绑定**：07-05 探测时 `6806` 上跑的是另一个独立的测试工作区（笔记本 `test`，看不到 `Official`）；07-06 内核重启后，同一个内核进程**同时**监听了随机端口和 `6806`（`lsof -iTCP:6806 -sTCP:LISTEN` 确认是同一个 PID）。两次结论不同，说明这条绑定不是内核的恒定行为，触发条件目前没有确证。
- 纪律：
  1. 不要假设 `6806` = 主工作区，也不要假设 `6806` = 测试工作区——每次都用 `lsof -iTCP:6806 -sTCP:LISTEN`（看 PID 是否和当前主内核一致）+ `lsNotebooks`（看笔记本列表里有没有 `Official`）现场确认，不要凭上次经验判断这次。
  2. 只要怀疑“是不是连错思源了”，做一次 `lsNotebooks` + `getHPathByID(<目标文档ID>)`，必要时对照桌面端窗口 URL。
  3. **如果 `6806`（以及已知的随机端口）都探测无响应**：不要自己继续猜别的端口号硬扛，直接停下来问用户二选一——(a) 麻烦重启一下思源，或 (b) 把思源界面当前显示的随机端口告诉我（设置 → 关于，或应用内的网络访问提示条会显示）。这是唯一可靠的现场信息源，扫端口猜是浪费时间。

## 操作面（surface）选择

- **HTTP API / Kernel CLI**：主操作面。两者都写同一个运行中的内核。
- **`.sy` 文件**：主验证面。**严禁作为常规写入面**。只有在反复尝试 HTTP API / Kernel CLI / 当前可用 MCP 等正常写法后，仍确认做不到、且目标只能靠直接改 `.sy` 才可能完成时，才允许把它作为最后候选；并且动手前必须先向用户说明卡点并获得明确批准。
- **Built-in MCP**：候选面。仅当当前会话真实暴露出可调用的思源 MCP 工具时才算可用。Codex 侧 `codex mcp add` 实测写入配置成功但 `codex mcp list` 不显示（2026-07-04）；迁移到 Claude 侧后值得重探一次。
- MCP 工具层是手工塑形的适配层，不是 HTTP 端点的透传——语义差异见 core-source-notes 的 MCP 条目。
- 如果本机同时跑着多个内核，先确认你连的是**哪一个工作区**，再谈 HTTP / CLI / MCP 选型；“端口对了没有”是比“API 能不能用”更前置的判断。

## 本机网络注意

- 本机代理工具（Surge）可能截走 `127.0.0.1:<port>` 请求。curl 探测时显式绕过：
  `env -u http_proxy -u https_proxy -u HTTP_PROXY -u HTTPS_PROXY -u ALL_PROXY -u all_proxy curl ...`
- Node 的 `fetch` 默认不读代理环境变量，脚本走 Node 更省心（本 skill 的脚本均为 Node）。

## API 认证

- 脚本读环境变量 `SIYUAN_API_TOKEN`，发送 `Authorization: Token <token>` 头。
- Token 在思源 **设置 → 关于** 可查，也在 MCP URL 的 `?token=` 参数里。
- **2026-07-05 起主工作区已开启 accessAuthCode：全部 API 必须带 token**，否则一律 `-1 Auth failed [session]`（此前 localhost 免验证的结论作废）。症状特征：所有端点统一返回 -1 + 该 msg，先想到鉴权，别当成端点坏了。
- Token 获取：`workspace/conf/conf.json` 的 `api.token`，**进程内读取直接用于请求头，不要打印到 stdout / 记录**（凭据落纸面会被安全策略拦，也不该落）。
- **`accessAuthCode`（锁屏密码／访问授权码）和 `api.token`（API Token）是 `conf.json` 里两个独立字段，不是同一个值**：
  - `accessAuthCode` 是网络访问提示条里说的"锁屏密码"，用来保护 UI/局域网登录；`api.token` 是单独给 HTTP API/MCP 鉴权用的字符串，在设置 → 关于单独查看/重置。
  - 两者的关联只在于**开关**：设了 `accessAuthCode` 之后，内核会把 API 鉴权从"可选"切成"强制"（这正是上面那条 2026-07-05 现象的成因），但校验用的凭据仍然是 `api.token`，不是 `accessAuthCode` 本身。
  - 所以：改锁屏密码不会连带改变 `api.token` 的值，脚本/MCP 配置里存的旧 token 照样有效；只有你自己在设置里手动重置 API token 时，token 的值才会变，到时候才需要同步更新脚本配置和 `~/.claude/settings.json` 的 MCP URL。

## CSS 代码片段（data/snippets/conf.json）

- 已启用：**表格宽度不超出编辑器** — `.protyle-wysiwyg .table table { max-width: 100%; }`
- 片段文件是 JSON 数组，每项含 `id`/`name`/`type`(css|js)/`enabled`/`content`。注意 `getFile` 对该文件有敏感路径限制（非管理员上下文被拒）。

## 邻居工具

- **Obsidian 官方 CLI**: `/Applications/Obsidian.app/Contents/MacOS/obsidian-cli`（可用 `links` 拿 Obsidian 自己的链接解析、`base:query` 导出 Bases 数据——跨工具对账时有用）
- Obsidian 库: `/Users/lonefireblossom/Documents/Mooncell/Mooncell-Obsidian`（只读对待；迁移事宜见 obsidian-to-siyuan-exam-notes skill 与会话记忆）
